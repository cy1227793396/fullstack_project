// 页面标题配置
export const pageTitle = {
    '/': '首页',
    '/home': '首页',
    '/order': '订单',
    '/find': '发现',
    '/mine': '我的',
}