import React, { useState, useEffect } from 'react';
// import { } from './style'

const Find = () => {
    return (
        <div>
            Find
        </div>
    )
}

export default Find