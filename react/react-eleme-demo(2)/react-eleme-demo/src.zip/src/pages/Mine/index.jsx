import React, { useState, useEffect } from 'react';
// import { } from './style'

const Mine = () => {
    return (
        <div>
            Mine
        </div>
    )
}

export default Mine