import React, { useState, useEffect } from 'react';
// import { } from './style'

const Order = () => {
    return (
        <div>
            Order
        </div>
    )
}

export default Order